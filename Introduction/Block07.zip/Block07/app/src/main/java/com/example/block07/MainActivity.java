package com.example.block07;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.NumberPicker;

public class MainActivity extends AppCompatActivity {
    NumberPicker numberPicker;
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NumberPicker numberPicker=(NumberPicker)findViewById(R.id.np1);
        webView=(WebView)findViewById(R.id.wbv);
        String[] allvalues={"Android", "Checklist", "Coursera","Superlec"};

        numberPicker.setDisplayedValues(allvalues);
        numberPicker.setMinValue(0);
        numberPicker.setMaxValue(allvalues.length-1);

    }
    public  void  navigate(View v)
    {
        int choice=numberPicker.getValue();
        if(choice==0){
            webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_assets/android.html");}
        else if(choice==1)
        {
            webView.loadUrl("file:///android_assets/checklist.html");}
        else if(choice==2)
        {

            webView.loadUrl("http://www.coursera.org");
        }
        else if(choice==3)
        {
            webView.loadUrl("file:///android_assets/supelec.html");
        }
        }

}
