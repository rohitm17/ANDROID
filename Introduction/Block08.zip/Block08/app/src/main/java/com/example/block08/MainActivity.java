package com.example.block08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
RatingBar ratingBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void enter(View v)
    {
        ratingBar=(RatingBar)findViewById(R.id.ratingBar);
        float rating=ratingBar.getRating();
        Toast.makeText(getApplicationContext(),rating+" stars",Toast.LENGTH_SHORT).show();

        Intent gotosecond=new Intent();
        gotosecond.setClass(this,SecondActivity.class);
        gotosecond.putExtra("NBstars",rating);
        startActivity(gotosecond);
        finish();
    }
}
