package com.example.dummy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    private Button[][] buttons=new Button[3][3];
    private  boolean player1Turn =true;
    private int roundCount;
    private int player1point;
    private  int player2point;

    private TextView tvp1;
    private  TextView tvp2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvp1=(TextView)findViewById(R.id.p1);
        tvp2=(TextView)findViewById(R.id.p2);

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                String buttonID="b"+i+j;
                int resID=getResources().getIdentifier(buttonID,"id",getPackageName());
                buttons[i][j]=findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }
        Button breset=(Button)findViewById(R.id.reset);
        breset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetGame();
            }
        });
    }

    @Override
    public void onClick(View view) {

        if(!((Button)view).getText().toString().equals(""))
        {
                return;
        }
        if(player1Turn)
        {
            ((Button)view).setText("X");
        }
        else
        {
            ((Button)view).setText("O");
        }
        roundCount++;
        if(checkForWin())
        {
            if(player1Turn)
            {
                player1win();
            }
            else
            {
                player2win();
            }
        }
        else if(roundCount==9)
        {
            drawOfBoth();
        }
        else
        {
            player1Turn=!player1Turn;
        }

    }
    private boolean checkForWin()
    {
        String[][] field=new  String[3][3];
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                field[i][j]=buttons[i][j].getText().toString();
            }
        }
        for(int i=0;i<3;i++)
        {
            if(field[i][0].equals(field[i][1]) && field[i][0].equals(field[i][2]) && !field[i][0].equals(""))
            {
                return true;
            }
        }

        for(int i=0;i<3;i++)
        {
            if(field[0][i].equals(field[1][i]) && field[0][i].equals(field[2][i]) && !field[0][i].equals(""))
            {
                return true;
            }
        }
        if(field[0][0].equals(field[1][1]) && field[0][0].equals(field[2][2]) && !field[0][0].equals(""))
        {
            return true;
        }
        if(field[0][2].equals(field[1][1]) && field[0][2].equals(field[2][0]) && !field[0][2].equals(""))
        {
            return true;
        }

        return false;
    }
    private void player1win()
    {
        player1point++;
        Toast.makeText(this,"Player 1 wins", Toast.LENGTH_SHORT).show();
        updatePoints();
        resetBoard();
    }
    private void player2win()
    {
        player2point++;
        Toast.makeText(this,"Player 2 Wins",Toast.LENGTH_SHORT).show();
        updatePoints();
        resetBoard();
    }
    private void drawOfBoth()
    {
            Toast.makeText(this,"Draw between tow of you",Toast.LENGTH_SHORT).show();
        resetBoard();
    }
    private void updatePoints()
    {
        tvp1.setText("Player 1 :"+player1point);
        tvp2.setText("Player 2 :"+player2point);
    }
    private  void resetBoard()
    {
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                buttons[i][j].setText("");
            }
        }
        roundCount=0;
        player1Turn=true;

    }
    private void resetGame()
    {
        player1point=0;
        player2point=0;
        updatePoints();
        resetBoard();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("roundCount",roundCount);
        outState.putInt("player1point",player1point);
        outState.putInt("player2point",player2point);
        outState.putBoolean("player1Turn",player1Turn);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        roundCount=savedInstanceState.getInt("roundCount");
        player1point=savedInstanceState.getInt("player1point");
        player2point=savedInstanceState.getInt("player2point");
        player1Turn=savedInstanceState.getBoolean("player1Turn");
    }
}
